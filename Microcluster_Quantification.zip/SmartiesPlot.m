function [clabel,cmap]=SmartiesPlot(hes5int,bw,Hist_level,colors,haxis,opt)
% divide intensities into grid
    [counts,xgrid]=hist(hes5int,Hist_level); 
    % section adapted ColourMap.m
    for i=1:numel(hes5int)
        xi=hes5int(i);
        % find nearest intensity on grid
        crit=(xgrid-xi).^2;
        idx=find(crit==min(crit),1,'first');
        % assign corresponding color
        cmap(i,:)=colors(idx,:);
        clabel(i)=idx;
    end
    % end of section from ColourMap
    % section from ColourMapMain
    [labeled,n]=bwlabeln(bw);
    rgb=label2rgb(labeled,cmap);
    if opt==1
        axis(haxis); imshow(rgb);
        colormap viridis %magma
        h=colorbar('Location','WestOutside');
%         if min(hes5int) < 0
%             disp('Error negative values')
%         end
        set(h,'TickLabels',round([0:0.1:1]*(max(hes5int)-min(hes5int))+min(hes5int)));
    end
end