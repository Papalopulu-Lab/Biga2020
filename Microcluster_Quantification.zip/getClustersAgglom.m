function [clabel,count,clbws]=getClustersAgglom(flstruct,clidx,blevel) 
bw=flstruct.bw;
% labelled image
lab=bwlabeln(bw);
rg=regionprops(lab,'Orientation');
phi=mean([rg.Orientation]);
% find nuclei assigned to intensity bin level
idxs=find(clidx==blevel);
% select those nuclei
bws=ismember(lab,idxs);
lab=bwlabeln(bws);
% identify centroids
reg=flstruct.reg; regs=reg(idxs);
c=cat(1,[regs(:).Centroid]);
c=reshape(c,2,numel(regs))';
% identify distance matrix
ccdist=flstruct.ccdist; 
for i=1:numel(idxs)
    ccdists(i,:)=ccdist(idxs(i),idxs);
end
% search for clusters within mean+SD
thresh=flstruct.ccmean;%+flstruct.ccsd;
hthresh=floor(thresh/2.5);
% dilate the regions to obtain clusters
clbws=imdilate(bws,strel('disk',hthresh));
saveclbws=clbws;
% remove interceding cells from clusters
bw0=bw; bw0(bws)=0;
rem=imdilate(bw0,strel('line',floor(thresh),phi));
rem=imdilate(rem,strel('disk',floor(thresh/2.5)));
%subplot(2,3,5),imshow(clbws);
clbws(rem)=0;
%subplot(2,3,6),imshow(clbws);
% find objects in the cluster mask
[cllab,n]=bwlabeln(uint8(clbws));
for i=1:numel(regs)
    now=(lab==i);
    clabel(i)=max(cllab(now));%mean(cllab(now));
end
% identify any cluster of 1 cell; count clusters of min 2
count=[];
for i=1:n
    cidx=find(clabel==i);
    if numel(cidx)==1
        clabel(cidx)=NaN;
    elseif ~isempty(cidx)
        count=[count, numel(cidx)];
    end
end
%% visalise clusters
%subplot(2,3,2),imshow(bws)
vals=unique(clabel); %vals(isnan(vals))=[];
cmap=zeros(numel(clabel),3);
colors=jet(numel(vals));
n=1;
for k=1:numel(clabel)
    if ~isnan(clabel(k))
        idx=find(vals==clabel(k));
        cmap(k,:)=colors(idx,:);
    end
end
% plot the clustered as colormap
% rgb=label2rgb(lab,cmap);
%imshow(rgb)