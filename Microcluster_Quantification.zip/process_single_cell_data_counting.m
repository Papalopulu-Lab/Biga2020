clear all, close all, clc
% list of images and corresponding segmented maps
fl{1}.hes5='Exp1a.png';
fl{1}.d5='Exp1a_D5.png';
fl{1}.nucl='Exp1a_nuclmap.png';
%
fl{2}.hes5='Exp1b.png';
fl{2}.d5='Exp1b_D5.png';
fl{2}.nucl='Exp1b_nuclmap.png';
%
fl{3}.hes5='Exp2e.png';
fl{3}.d5='Exp2e_D5.png';
fl{3}.nucl='Exp2e_nuclmap.png';
%
fl{4}.hes5='Exp2h.png';
fl{4}.d5='Exp2h_D5.png';
fl{4}.nucl='Exp2h_nuclmap.png';
%
fl{5}.hes5='Exp3b.png';
fl{5}.d5='Exp3b_D5.png';
fl{5}.nucl='Exp3b_nuclmap.png';
%
fl{6}.hes5='Exp3c.png';
fl{6}.d5='Exp3c_D5.png';
fl{6}.nucl='Exp3c_nuclmap.png';
%
fl{7}.hes5='Exp3f.png';
fl{7}.d5='Exp3f_D5.png';
fl{7}.nucl='Exp3f_nuclmap.png';
%
fl{8}.hes5='Exp2j.png'; 
fl{8}.d5='Exp2j_D5.png'; 
fl{8}.nucl='Exp2j_nuclmap.png';
%
fl{9}.hes5='Exp5a.png';
fl{9}.d5='Exp5a_D5.png';
fl{9}.nucl='Exp5a_nuclmap.png';
%
fl{10}.hes5='Exp5b.png';
fl{10}.d5='Exp5b_D5.png';
fl{10}.nucl='Exp5b_nuclmap.png';
%
fl{11}.hes5='Exp6a.png';
fl{11}.d5='Exp6a_D5.png';
fl{11}.nucl='Exp6a_nuclmap.png';
%
fl{12}.hes5='Exp6b.png';
fl{12}.d5='Exp6b_D5.png';
fl{12}.nucl='Exp6b_nuclmap.png';
%
fl{13}.hes5='Exp7.png';
fl{13}.d5='Exp7_D5.png';
fl{13}.nucl='Exp7_nuclmap.png';
%
fl{14}.hes5='40x_z1.png';
fl{14}.d5='40x_z1_D5.png';
fl{14}.nucl='40x_z1_nuclmap.png';
%% remove dead cells based on high Draq5 intensity
for i=1:numel(fl)
    hes5=imread(fl{i}.hes5); hes5=rgb2gray(hes5);
    draq5=imread(fl{i}.d5); draq5=rgb2gray(draq5);
    nucl=imread(fl{i}.nucl); nucl=logical(nucl);
    [lab,n]=bwlabeln(nucl);
    reg=regionprops(lab,draq5,'MeanIntensity','Centroid');
    d5int=cat(1,[reg(:).MeanIntensity]);
    lim95=prctile(d5int,96);
    if max(d5int)>220
        idx=find(d5int<lim95);
        lab=ismember(lab,idx);
    end
    bw=lab>0;
    % save the images
    fl{i}.hes5image=hes5;
    fl{i}.d5image=draq5;
    fl{i}.nucl=nucl; % nuclear mask after minor edits
    fl{i}.bw=bw; % nuclear mask after removal of dead cells
end
%% initialise variables
intmat=NaN*ones(300,numel(fl));
xcmat=NaN*ones(300,numel(fl));
ycmat=NaN*ones(300,numel(fl));
%% extract single cell centroid locations; compute cell-cell distance matrix
for i=1:numel(fl)
    ven=fl{i}.hes5image;
    bw=fl{i}.bw;
    % adjust venus by new mask
    ven(bw==0)=0; % this turns everything into black background; set to 255 for white
    reg=regionprops(bw,ven,'MeanIntensity','Centroid');
    fl{i}.reg=reg;
    % collect and save intensities
    int=cat(1,[reg(:).MeanIntensity]);
    c=cat(1,[reg(:).Centroid]);
    c=reshape(c,2,numel(reg))';
    intmat(1:numel(int),i)=int(:);
    xcmat(1:size(c,1),i)=c(:,1);
    ycmat(1:size(c,1),i)=c(:,2);
    % average cell-cell dist per experiment
    dist=zeros(numel(reg),numel(reg));
    for j=1:numel(reg)
        xx=sqrt((c(j,1)-c(:,1)).^2+(c(j,2)-c(:,2)).^2);
        dist(j,:)=xx;
        % set dist to itself to max
        dist(j,j)=Inf;
    end
    fl{i}.ccdist=dist;
    fl{i}.ccmean=mean(min(dist));
    fl{i}.ccsd=std(min(dist));
end
%% quantile norm intensities
% group into experiments before quantile norm
intmat_grouped=NaN*ones(600,11);
intmat_grouped(:,1)=[intmat(:,1); intmat(:,2)];
intmat_grouped(1:300,2:7)=intmat(:,3:8);
intmat_grouped(:,8)=[intmat(:,9); intmat(:,10)];
intmat_grouped(:,9)=[intmat(:,11); intmat(:,12)];
intmat_grouped(1:300,10)=intmat(:,13);
intmat_grouped(1:300,11)=intmat(:,14);
intmat_norm=quantilenorm(intmat_grouped);
% reorder it back again
intmat_norm_split=NaN*ones(300,14);
intmat_norm_split(:,1)=intmat_norm(1:300,1);
intmat_norm_split(:,2)=intmat_norm(301:600,1);
intmat_norm_split(:,3:8)=intmat_norm(1:300,2:7);
intmat_norm_split(:,9)=intmat_norm(1:300,8);
intmat_norm_split(:,10)=intmat_norm(301:600,8);
intmat_norm_split(:,11)=intmat_norm(1:300,9);
intmat_norm_split(:,12)=intmat_norm(301:600,9);
intmat_norm_split(:,13)=intmat_norm(1:300,10);
intmat_norm_split(:,14)=intmat_norm(1:300,11);
%% plot as smarties 
Hist_level=6;
colors=viridis(Hist_level);
COUNTS=[];
COUNTS1=[];
COUNTS2=[];
for k=1:numel(fl)
    hes5int=intmat_norm_split(:,k);
    hes5int(isnan(hes5int))=[];
    figure;
    h=subplot(2,4,[1,5]);
    bw=fl{k}.bw;
    [clidx,~]=SmartiesPlot(hes5int,bw,Hist_level,colors,h,1); 
    title('Quantile norm image');
    % threshold the image at level 6 and get cluster stats
    [clabel, counts,bwclust,cent]=getClustersAgglom1(fl{k},clidx,Hist_level);
    fl{k}.bwclust=bwclust;
    fl{k}.clabel=clabel;
    fl{k}.centroids=cent;
    COUNTS=[COUNTS; counts(:)];
    for j=1:10 % increase to produce more randomisations
        % randomisation 1- permute the position of same intesities
        kidx=randperm(numel(hes5int));
        permhes5int=hes5int(kidx);
        if j<4
            h=subplot(2,4,j+1);
            [clidx,~]= SmartiesPlot(permhes5int,bw,Hist_level,colors,h,1);
        else
            [clidx,~]= SmartiesPlot(permhes5int,bw,Hist_level,colors,h,0);
        end
        title(['Rnd1-' num2str(j)]); %('Randomised positions');
        [clabel, counts]=getClustersAgglom(fl{k},clidx,Hist_level);
        COUNTS1=[COUNTS1; counts(:)];
    end
    for j=1:10
        % randomisation 2- intensities of the same mean SD
        m=mean(hes5int);
        sd=std(hes5int);
        randhes5int=randn(1,numel(hes5int))*sd+m;
        if j<4
            h=subplot(2,4,j+5);
            [clidx,~]=SmartiesPlot(randhes5int,bw,Hist_level,colors,h,1);
        else
            [clidx,~]=SmartiesPlot(randhes5int,bw,Hist_level,colors,h,0);
        end
        [clabel, counts]=getClustersAgglom(fl{k},clidx,Hist_level);
        title (['Rnd2-' num2str(j)]); %('Randomised intensities');
        COUNTS2=[COUNTS2; counts(:)];
    end
end
%% plot the counts
m=max([numel(COUNTS),numel(COUNTS1),numel(COUNTS2)]);
countmat=NaN*ones(m,3);
countmat(1:numel(COUNTS),1)=COUNTS(:);
countmat(1:numel(COUNTS1),2)=COUNTS1(:);
countmat(1:numel(COUNTS2),3)=COUNTS2(:);
figure,boxplot(countmat)
title('Data vs randomised controls');
ylabel('Cluster size (no. of cells)');
set(gca,'XTickLabel',{'E10.5','Rnd1','Rn2'});
